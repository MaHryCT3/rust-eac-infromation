# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['eac_info']

package_data = \
{'': ['*']}

install_requires = \
['aiohttp>=3.8.1,<4.0.0', 'beautifulsoup4>=4.11.1,<5.0.0', 'lxml>=4.9.1,<5.0.0']

setup_kwargs = {
    'name': 'rust-eac-information',
    'version': '0.1.0',
    'description': 'Get infromation about eac banned players in rust',
    'long_description': '',
    'author': 'MaHryCT3',
    'author_email': 'mahryct123@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': 'https://github.com/MaHryCT3/rust-eac-infromation',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
