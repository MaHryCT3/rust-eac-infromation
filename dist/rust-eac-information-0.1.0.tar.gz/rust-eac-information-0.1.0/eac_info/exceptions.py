class CantGetEacInfo:
    """Raised for errors when does not work get information about eac."""


class SteamIsNotFound:
    """Raised for errors when does not found a Steam account."""
